$(function() {

    //code

   	$(".js_click_btn").text();


});
