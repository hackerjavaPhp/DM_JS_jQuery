;

$(document).ready(function(){

	// code jQuery

	

});