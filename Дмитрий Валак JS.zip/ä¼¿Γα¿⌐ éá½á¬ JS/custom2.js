;

$(document).ready(function(){

	// code jQuery

	alert("Hello World");

});